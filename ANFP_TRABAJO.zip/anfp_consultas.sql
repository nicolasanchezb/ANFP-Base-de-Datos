SELECT
    a.id_asociacion || ' ' || a.nombre_asociacion AS nombre_asociacion,
    TO_CHAR(a.fecha_creacion, 'DD-MM-YYYY') AS fecha_creacion,
    a.tipo_asociacion
FROM ASOCIACION a
WHERE a.tipo_asociacion = 'P'
  AND a.fecha_creacion >= DATE '2001-01-01'
ORDER BY a.fecha_creacion DESC;

-- INFORME 2: Patrimonio de clubes en pesos y dólares.
-- Tipo de cambio solicitado: 955 pesos por dólar.

SELECT
    id_club,
    nombre_club,
    patrimonio AS patrimonio_pesos,
    ROUND(patrimonio / 955, 2) AS patrimonio_dolares
FROM CLUB_FUTBOL
WHERE LOWER(nombre_club) LIKE '%a%'
  AND patrimonio > 200000000
  AND tipo_club = 'Profesional'
ORDER BY id_club DESC;