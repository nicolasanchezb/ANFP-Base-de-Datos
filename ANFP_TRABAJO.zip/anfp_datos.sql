-- POBLAMIENTO ANFP
-- Ejecutar como PRY2204_S9 sobre las tablas vacías.

-- REGION

INSERT INTO REGION (id_region, nombre_region)
VALUES (1, 'ARICA Y PARINACOTA Y TARAPACA');

INSERT INTO REGION (id_region, nombre_region)
VALUES (2, 'ANTOFAGASTA');

INSERT INTO REGION (id_region, nombre_region)
VALUES (3, 'ATACAMA Y COQUIMBO');

INSERT INTO REGION (id_region, nombre_region)
VALUES (5, 'VALPARAISO');

INSERT INTO REGION (id_region, nombre_region)
VALUES (13, 'METROPOLITANA');

-- Regiones adicionales necesarias para Concepción y Chillán.
INSERT INTO REGION (id_region, nombre_region)
VALUES (8, 'BIOBIO');

INSERT INTO REGION (id_region, nombre_region)
VALUES (16, 'ÑUBLE');

-- COMUNA

INSERT INTO COMUNA (id_comuna, nombre_comuna, REGION_id_region)
VALUES (101, 'Santiago', 13);

INSERT INTO COMUNA (id_comuna, nombre_comuna, REGION_id_region)
VALUES (102, 'Valparaíso', 5);

INSERT INTO COMUNA (id_comuna, nombre_comuna, REGION_id_region)
VALUES (103, 'Concepción', 8);

INSERT INTO COMUNA (id_comuna, nombre_comuna, REGION_id_region)
VALUES (104, 'Antofagasta', 2);

INSERT INTO COMUNA (id_comuna, nombre_comuna, REGION_id_region)
VALUES (105, 'Chillán', 16);

-- ASOCIACION

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (25, 'Asociación de Fútbol de Santiago', DATE '2001-05-15', 'P');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (26, 'Asociación Nacional de Fútbol Amateur', DATE '1998-03-10', 'A');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (27, 'Asociación de Fútbol de Valparaíso', DATE '1987-07-21', 'P');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (28, 'Asociación de Fútbol de Concepción', DATE '1995-11-30', 'A');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (29, 'Asociación de Fútbol de Antofagasta', DATE '2003-06-25', 'P');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (30, 'Asociación de Fútbol de Temuco', DATE '2010-01-12', 'A');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (31, 'Asociación de Fútbol de Rancagua', DATE '1999-09-08', 'P');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (32, 'Asociación de Fútbol de Puerto Montt', DATE '2005-04-20', 'A');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (33, 'Asociación de Fútbol de La Serena', DATE '2012-08-14', 'P');

INSERT INTO ASOCIACION
    (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES
    (34, 'Asociación de Fútbol de Chillán', DATE '2018-12-01', 'A');

-- NACIONALIDAD
-- IDENTITY genera el identificador desde 210, de 2 en 2.

INSERT INTO NACIONALIDAD (descripcion)
VALUES ('Chilena');

INSERT INTO NACIONALIDAD (descripcion)
VALUES ('Argentina');

INSERT INTO NACIONALIDAD (descripcion)
VALUES ('Peruana');

INSERT INTO NACIONALIDAD (descripcion)
VALUES ('Boliviana');

INSERT INTO NACIONALIDAD (descripcion)
VALUES ('Brasileña');

-- CLUB_FUTBOL
-- La secuencia genera el código desde 703, de 4 en 4.

INSERT INTO CLUB_FUTBOL
    (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES
    (seq_club_futbol.NEXTVAL, 'Colo-Colo', 500000000,
     'Av. Marathon 5300', 'Profesional');

INSERT INTO CLUB_FUTBOL
    (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES
    (seq_club_futbol.NEXTVAL, 'Universidad de Chile', 450000000,
     'Av. El Parrón 0931', 'Profesional');

INSERT INTO CLUB_FUTBOL
    (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES
    (seq_club_futbol.NEXTVAL, 'Deportes Antofagasta', 180000000,
     'Avenida Angamos 01606', 'Profesional');

INSERT INTO CLUB_FUTBOL
    (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES
    (seq_club_futbol.NEXTVAL, 'Huachipato', 220000000,
     'Avenida Donoso García 909', 'Profesional');

INSERT INTO CLUB_FUTBOL
    (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES
    (seq_club_futbol.NEXTVAL, 'Ñublense', 170000000,
     'Avenida Pedro Aguirre Cerda 1003', 'Profesional');

COMMIT;